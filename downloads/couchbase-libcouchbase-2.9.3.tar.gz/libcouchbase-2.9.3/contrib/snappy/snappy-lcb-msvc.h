#ifdef _MSC_VER
#define NOMINMAX
#include <basetsd.h>
typedef SSIZE_T ssize_t;
#endif
