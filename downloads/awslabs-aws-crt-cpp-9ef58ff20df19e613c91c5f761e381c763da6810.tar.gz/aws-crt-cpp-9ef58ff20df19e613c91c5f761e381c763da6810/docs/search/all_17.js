var searchData=
[
  ['_7emanagedconnection_248',['~ManagedConnection',['../classAws_1_1Crt_1_1Http_1_1ManagedConnection.html#a9645af8d3a1c4e05c442403ba5ba7546',1,'Aws::Crt::Http::ManagedConnection']]],
  ['_7eunmanagedconnection_249',['~UnmanagedConnection',['../classAws_1_1Crt_1_1Http_1_1UnmanagedConnection.html#a07c2fa54147f38de138d4103fcf2595a',1,'Aws::Crt::Http::UnmanagedConnection']]]
];
