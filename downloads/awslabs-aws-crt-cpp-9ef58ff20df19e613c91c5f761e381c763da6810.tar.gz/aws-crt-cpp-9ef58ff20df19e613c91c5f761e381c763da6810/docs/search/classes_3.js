var searchData=
[
  ['elasticurlctx_256',['ElasticurlCtx',['../structElasticurlCtx.html',1,'']]],
  ['error_257',['error',['../structerror.html',1,'']]]
];
