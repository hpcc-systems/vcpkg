var searchData=
[
  ['delegatecredentialsprovidercallbackargs',['DelegateCredentialsProviderCallbackArgs',['../structAws_1_1Crt_1_1Auth_1_1DelegateCredentialsProviderCallbackArgs.html',1,'Aws::Crt::Auth']]]
];
