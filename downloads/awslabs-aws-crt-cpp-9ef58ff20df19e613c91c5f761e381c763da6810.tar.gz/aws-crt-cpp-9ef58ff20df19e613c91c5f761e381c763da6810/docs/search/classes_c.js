var searchData=
[
  ['websocketconfig_273',['WebsocketConfig',['../structAws_1_1Iot_1_1WebsocketConfig.html',1,'Aws::Iot']]],
  ['wrappedcallbackargs_274',['WrappedCallbackArgs',['../structAws_1_1Crt_1_1Imds_1_1WrappedCallbackArgs.html',1,'Aws::Crt::Imds']]]
];
