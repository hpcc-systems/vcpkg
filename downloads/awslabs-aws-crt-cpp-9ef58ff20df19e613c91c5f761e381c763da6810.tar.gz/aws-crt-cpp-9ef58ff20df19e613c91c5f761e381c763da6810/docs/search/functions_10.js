var searchData=
[
  ['unmanagedconnection_377',['UnmanagedConnection',['../classAws_1_1Crt_1_1Http_1_1UnmanagedConnection.html#a2d1787e67ecf9b3b14513b3f317527bb',1,'Aws::Crt::Http::UnmanagedConnection']]]
];
