var searchData=
[
  ['unmanagedconnection',['UnmanagedConnection',['../classAws_1_1Crt_1_1Http_1_1UnmanagedConnection.html',1,'Aws::Crt::Http']]]
];
