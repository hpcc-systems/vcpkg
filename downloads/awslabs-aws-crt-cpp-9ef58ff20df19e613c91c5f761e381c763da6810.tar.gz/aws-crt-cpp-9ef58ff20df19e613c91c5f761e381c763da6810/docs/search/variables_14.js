var searchData=
[
  ['unsignedpayload_490',['UnsignedPayload',['../namespaceAws_1_1Crt_1_1Auth_1_1SignedBodyValue.html#a3516e377bf8e746e39ef48d8a1a2f9e9',1,'Aws::Crt::Auth::SignedBodyValue']]],
  ['uri_491',['uri',['../structElasticurlCtx.html#a7422cece7ca10562b68fdfca763bb321',1,'ElasticurlCtx']]],
  ['userdata_492',['userData',['../structAws_1_1Crt_1_1Imds_1_1WrappedCallbackArgs.html#a6ba7e398f894cd87c73387375cbe238b',1,'Aws::Crt::Imds::WrappedCallbackArgs']]]
];
