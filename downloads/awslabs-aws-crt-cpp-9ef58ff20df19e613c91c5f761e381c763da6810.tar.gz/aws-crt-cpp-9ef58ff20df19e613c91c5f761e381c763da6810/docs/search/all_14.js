var searchData=
[
  ['unmanagedconnection_218',['UnmanagedConnection',['../classAws_1_1Crt_1_1Http_1_1UnmanagedConnection.html',1,'Aws::Crt::Http::UnmanagedConnection'],['../classAws_1_1Crt_1_1Http_1_1UnmanagedConnection.html#a2d1787e67ecf9b3b14513b3f317527bb',1,'Aws::Crt::Http::UnmanagedConnection::UnmanagedConnection()']]],
  ['unsignedpayload_219',['UnsignedPayload',['../namespaceAws_1_1Crt_1_1Auth_1_1SignedBodyValue.html#a3516e377bf8e746e39ef48d8a1a2f9e9',1,'Aws::Crt::Auth::SignedBodyValue']]],
  ['uri_220',['uri',['../structElasticurlCtx.html#a7422cece7ca10562b68fdfca763bb321',1,'ElasticurlCtx']]],
  ['uri_2ecpp_221',['Uri.cpp',['../Uri_8cpp.html',1,'']]],
  ['userdata_222',['userData',['../structAws_1_1Crt_1_1Imds_1_1WrappedCallbackArgs.html#a6ba7e398f894cd87c73387375cbe238b',1,'Aws::Crt::Imds::WrappedCallbackArgs']]],
  ['uuid_2ecpp_223',['UUID.cpp',['../UUID_8cpp.html',1,'']]]
];
