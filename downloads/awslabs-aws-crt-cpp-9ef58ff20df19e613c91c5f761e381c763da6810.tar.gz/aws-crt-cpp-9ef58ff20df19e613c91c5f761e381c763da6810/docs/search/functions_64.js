var searchData=
[
  ['defaultallocator',['DefaultAllocator',['../namespaceAws_1_1Crt.html#a90f34896c313e2958262a0174d6c5aa7',1,'Aws::Crt']]],
  ['delegatecredentialsprovidercallbackargs',['DelegateCredentialsProviderCallbackArgs',['../structAws_1_1Crt_1_1Auth_1_1DelegateCredentialsProviderCallbackArgs.html#a87ee7bbdfa604c70832eca08415a6514',1,'Aws::Crt::Auth::DelegateCredentialsProviderCallbackArgs']]]
];
