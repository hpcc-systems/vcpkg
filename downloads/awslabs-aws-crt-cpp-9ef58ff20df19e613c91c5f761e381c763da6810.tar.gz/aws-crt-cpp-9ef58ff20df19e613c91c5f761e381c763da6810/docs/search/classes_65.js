var searchData=
[
  ['elasticurlctx',['ElasticurlCtx',['../structElasticurlCtx.html',1,'']]],
  ['error',['error',['../structerror.html',1,'']]]
];
