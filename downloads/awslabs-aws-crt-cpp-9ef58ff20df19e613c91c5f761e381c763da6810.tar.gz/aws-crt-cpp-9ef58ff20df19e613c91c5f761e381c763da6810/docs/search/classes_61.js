var searchData=
[
  ['adaptivehttpproxystrategy',['AdaptiveHttpProxyStrategy',['../classAws_1_1Crt_1_1Http_1_1AdaptiveHttpProxyStrategy.html',1,'Aws::Crt::Http']]]
];
