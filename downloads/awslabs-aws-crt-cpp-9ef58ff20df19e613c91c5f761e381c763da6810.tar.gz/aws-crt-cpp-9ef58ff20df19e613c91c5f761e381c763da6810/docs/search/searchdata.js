var indexSectionsWithContent =
{
  0: "_abcdefghijklmnoprstuvw~",
  1: "acdehimopstuw",
  2: "a",
  3: "abcdehijmrstu",
  4: "abcdefhiklmnoprsuvw~",
  5: "_abcdefghijklmnoprstuvw",
  6: "ci",
  7: "m",
  8: "bceins",
  9: "acdw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "related",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Friends",
  8: "Macros",
  9: "Pages"
};

