var namespaces =
[
    [ "boost", null, [
      [ "locale", "namespaceboost_1_1locale.html", "namespaceboost_1_1locale" ]
    ] ]
];