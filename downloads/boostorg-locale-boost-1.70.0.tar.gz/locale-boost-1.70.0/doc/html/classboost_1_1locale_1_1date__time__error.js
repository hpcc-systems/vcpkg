var classboost_1_1locale_1_1date__time__error =
[
    [ "date_time_error", "classboost_1_1locale_1_1date__time__error.html#abbd57421fc4617b23ecb33c398152dc8", null ]
];