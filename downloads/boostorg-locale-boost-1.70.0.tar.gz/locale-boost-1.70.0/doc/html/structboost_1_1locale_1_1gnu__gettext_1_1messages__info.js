var structboost_1_1locale_1_1gnu__gettext_1_1messages__info =
[
    [ "domain", "structboost_1_1locale_1_1gnu__gettext_1_1messages__info_1_1domain.html", "structboost_1_1locale_1_1gnu__gettext_1_1messages__info_1_1domain" ],
    [ "callback_type", "structboost_1_1locale_1_1gnu__gettext_1_1messages__info.html#a4dfe37c5a392e5106e65b396a5288b76", null ],
    [ "domains_type", "structboost_1_1locale_1_1gnu__gettext_1_1messages__info.html#ac3bfe22cf949ed3f87ee28fa0c983502", null ],
    [ "messages_info", "structboost_1_1locale_1_1gnu__gettext_1_1messages__info.html#a54b92be28c96b6683519b068028e0468", null ],
    [ "callback", "structboost_1_1locale_1_1gnu__gettext_1_1messages__info.html#a63bd8b01ca532a2657186bab3fa396a2", null ],
    [ "country", "structboost_1_1locale_1_1gnu__gettext_1_1messages__info.html#ae939e0c5dbabba7fb4cc2872f4e7dac2", null ],
    [ "domains", "structboost_1_1locale_1_1gnu__gettext_1_1messages__info.html#a1ca79b90b4b8dbc924e5eb1b42188311", null ],
    [ "encoding", "structboost_1_1locale_1_1gnu__gettext_1_1messages__info.html#a4a7406581c6c7975c90db9d2d157d384", null ],
    [ "language", "structboost_1_1locale_1_1gnu__gettext_1_1messages__info.html#a1afc3be03d4848042e3208d4ca5aec85", null ],
    [ "locale_category", "structboost_1_1locale_1_1gnu__gettext_1_1messages__info.html#a39ea1cfd018c7702d94d03e76042ff10", null ],
    [ "paths", "structboost_1_1locale_1_1gnu__gettext_1_1messages__info.html#a263d9d2c359ae7730e6d5bba54bb3022", null ],
    [ "variant", "structboost_1_1locale_1_1gnu__gettext_1_1messages__info.html#af543a11d3ff1d12e24c06306b30f8fb8", null ]
];