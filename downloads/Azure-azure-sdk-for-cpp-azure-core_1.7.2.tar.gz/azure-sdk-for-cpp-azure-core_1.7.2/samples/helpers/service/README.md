# Generic Service for Samples

This is a helper library for samples that provides a generic service client library.
