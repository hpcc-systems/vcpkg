/*******************************************************************************
Copyright � 1999-2009 by Text Analysis International, Inc.
All rights reserved.
********************************************************************************
*/

WEB_API void ShowBanner();									// 03/02/99 AM.
WEB_API void ShowUsage();										// 03/02/99 AM.
WEB_API BOOL ParseOptions(int argc, _TCHAR* argv[],
		/*UP*/ _TCHAR* &urlfile);	// 03/02/99 AM.

WEB_API bool init_MFC();				// 02/28/99 AM.

