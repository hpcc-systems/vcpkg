/****************************************
Copyright � 1995 by Conceptual Systems.
Copyright (c) 1995 by Conceptual Systems.
All rights reserved.
*****************************************/ 
/*******************************************************************************
*
*									DICT.H
*
* FILE:	ext.�/dict.h
* SUBJ:	Declarations for dictionary manager.
* CR:	10/22/95 AM.
* NOTE:	
*
*******************************************************************************/

//extern LIBKBM_API bool		 dict_add_punct();
//extern LIBKBM_API CON		*dict_add_unknown(char *name);
//extern LIBKBM_API bool		 dict_add_white();
//extern LIBKBM_API CON		*dict_add_word(char *name);
//extern LIBKBM_API bool		 dict_rm_word(char *str);				// 07/17/00 AM.
//extern LIBKBM_API CON		*dict_find_index(CON *root, char *name);
//extern LIBKBM_API CON		*dict_find_index(char *name);			// 05/31/00 AM.
//extern LIBKBM_API CON		*dict_find_word(char *name);
//extern LIBKBM_API CON		*dict_find_word_lc(char *name);
