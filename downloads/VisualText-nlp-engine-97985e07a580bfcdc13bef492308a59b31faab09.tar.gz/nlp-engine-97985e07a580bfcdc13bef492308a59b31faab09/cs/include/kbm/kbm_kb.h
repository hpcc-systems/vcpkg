

//LIBKBM_API CON *
//con_phrase(
//	CON *con
//	);
//LIBKBM_API CON *
//phrase_con(
//	CON *phr
//	);
