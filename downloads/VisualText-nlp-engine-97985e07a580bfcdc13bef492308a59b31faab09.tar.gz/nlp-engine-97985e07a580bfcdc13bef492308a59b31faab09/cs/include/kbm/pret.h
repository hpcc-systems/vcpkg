/****************************************
Copyright � 1995 by Conceptual Systems.
Copyright (c) 1995 by Conceptual Systems.
All rights reserved.
*****************************************/ 
/*******************************************************************************
*
*									PRET.H
*
* FILE:	consh.�/pret.c
* SUBJ:	Pretty printers that mix modules.
* CR:		6/29/96 AM.
*
*******************************************************************************/
LIBKBM_API CON *
con_nth_proxy(
	CON *con,
	long nth
	);
