/****************************************
Copyright � 1995 by Conceptual Systems.
Copyright (c) 1995 by Conceptual Systems.
All rights reserved.
*****************************************/ 
/*******************************************************************************
*
*									RULE.H
*
* FILE:	conan.�/rule.h
* SUBJ:	Declarations for grammar rule management.
* CR:	11/9/95 AM.
*
*******************************************************************************/

extern long		 next_rule();