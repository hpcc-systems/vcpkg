/****************************************
Copyright � 1995 by Conceptual Systems.
Copyright (c) 1995 by Conceptual Systems.
All rights reserved.
*****************************************/ 
/*******************************************************************************
*
*									MEAN.H
*
* FILE:	conan.�/mean.h
* SUBJ:	Declares for MEANING REPRESENTATION subsystem.
* CR:		7/19/96 AM.
*
*******************************************************************************/

extern CON *mean_make();