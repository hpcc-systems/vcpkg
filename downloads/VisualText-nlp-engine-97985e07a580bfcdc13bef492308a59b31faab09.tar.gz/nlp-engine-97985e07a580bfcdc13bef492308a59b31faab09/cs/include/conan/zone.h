/****************************************
Copyright � 1995 by Conceptual Systems.
Copyright (c) 1995 by Conceptual Systems.
All rights reserved.
*****************************************/ 
/*******************************************************************************
*
*									ZONE.H
*
* FILE:	conan.�/zone.h
* SUBJ:	Declarations for zoning passes of analyzer.
* NOTE:	
* CR:	11/3/95 AM.
*
*******************************************************************************/

extern PN		 *zone_line_tree();
extern void		  zone_line_tree_rec();
extern PN		 *zone_lines();
extern void		  zone_lines_rec();