/****************************************
Copyright � 1995 by Conceptual Systems.
Copyright (c) 1995 by Conceptual Systems.
All rights reserved.
*****************************************/ 
/*******************************************************************************
*
*									HELP.H
*
* FILE:	consh.�/help.h
* SUBJ:	Declarations for help commands.
* CR:	11/11/95 AM.
*
*******************************************************************************/

extern bool
help_add(
	_t_ostream *out
	);
extern bool
help_ind(
	_t_ostream *out
	);
