#include "StdAfx.h"
#include <iostream>
#include <sstream>
#include "prim/libprim.h"

int xxx()
{
}
