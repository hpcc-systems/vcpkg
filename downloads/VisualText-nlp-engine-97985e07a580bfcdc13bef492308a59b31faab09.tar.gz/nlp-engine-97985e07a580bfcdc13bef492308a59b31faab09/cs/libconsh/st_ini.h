/*** AUTOMATICALLY GENERATED! EDITS WILL BE LOST. ***/

// RENAME.	// 02/26/19 AM.
#ifdef LINUX
extern bool ccx_st_ini(void *);		// 02/26/19 AM.
#else
extern bool cc_st_ini(void *);	// 08/15/02 AM.
#endif

//extern char St0[];															// 06/11/02 AM.
