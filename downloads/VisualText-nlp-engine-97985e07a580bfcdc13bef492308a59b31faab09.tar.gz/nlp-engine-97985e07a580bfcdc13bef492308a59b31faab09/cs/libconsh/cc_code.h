/*** CONAN: AUTOMATICALLY GENERATED! EDITS WILL BE LOST. ***/
/*** CONSH: HAND-EDITING OK ***/
/* Cc_code.h */

#ifdef LINUX
extern bool ccx_ini(void * = 0);										// 06/11/02 AM.
#else
extern bool cc_ini(void * = 0);										// 06/11/02 AM.
#endif
