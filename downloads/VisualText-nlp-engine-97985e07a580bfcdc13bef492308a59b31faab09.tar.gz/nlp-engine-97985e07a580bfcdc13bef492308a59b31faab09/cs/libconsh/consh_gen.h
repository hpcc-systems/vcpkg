/****************************************
Copyright � 1995 by Conceptual Systems.
Copyright (c) 1995 by Conceptual Systems.
All rights reserved.
*****************************************/ 
/*******************************************************************************
*
*									CONSH_GEN.H
*
* FILE:	conan.�/consh_gen.h
* SUBJ:	Declarations for Consh code generation.
* CR:	10/7/95 AM.
*
*******************************************************************************/

extern void
consh_gen_includes(
	std::_t_ofstream *fp
	);
