/*** CONAN: AUTOMATICALLY GENERATED! EDITS WILL BE LOST. ***/
/*** CONSH: HAND-EDITING OK ***/

// LINUX: Distinguish internal kb load from auto-generated kb load // 03/23/19 AM.
#ifdef LINUX
extern bool ccx_ptr_ini(void *cg);					// 08/15/02 AM.
#else
extern bool cc_ptr_ini(void *cg);					// 08/15/02 AM.
#endif

//extern PTR Ptr0[];
