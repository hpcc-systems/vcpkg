/*******************************************************************************
Copyright (c) 1999-2009 by Text Analysis International, Inc.
All rights reserved.
********************************************************************************
*
* NAME:	UTIL.H
* FILE:	web\util.h
* CR:		03/11/99 AM.
* SUBJ:	Primitives for this library.
*
*******************************************************************************/

#ifndef UTIL_H_
#define UTIL_H_

bool file_exists(const _TCHAR *iname);

#endif
