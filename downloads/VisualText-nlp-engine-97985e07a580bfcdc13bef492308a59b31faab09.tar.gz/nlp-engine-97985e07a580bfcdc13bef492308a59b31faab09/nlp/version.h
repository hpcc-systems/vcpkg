
/**
 * @brief Header file for version number function
 * @author Wolfram Rösler <wolfram@roesler-ac.de>
 * @date 2017-02-12
 */

char const *Version();