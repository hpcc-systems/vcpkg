/*******************************************************************************
Copyright (c) 1999-2010 by Text Analysis International, Inc.
All rights reserved.
********************************************************************************
*
* NAME:	MULTI.H
* FILE:	c:\lite\multi.h
* CR:		03/25/99 AM.
* SUBJ:	PAT algorithm mode for matching on all phrases in a subtree.
* NOTE:	Functions belong in PAT class, placed here for modularity.
*			
*
*******************************************************************************/

#ifndef MULTI_H_
#define MULTI_H_


#endif
