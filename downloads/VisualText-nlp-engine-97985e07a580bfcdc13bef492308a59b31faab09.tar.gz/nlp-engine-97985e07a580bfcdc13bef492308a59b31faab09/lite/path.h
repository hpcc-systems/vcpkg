/*******************************************************************************
Copyright (c) 1999-2010 by Text Analysis International, Inc.
All rights reserved.
********************************************************************************
*
* NAME:	PATH.H
* FILE:	c:\lite\path.h
* CR:		10/19/99 AM.
* SUBJ:	PAT algorithm mode for matching on nodes in a given path.
* NOTE:	Functions belong in PAT class, placed here for modularity.
*			
*
*******************************************************************************/

#ifndef PATH_H_
#define PATH_H_


#endif
