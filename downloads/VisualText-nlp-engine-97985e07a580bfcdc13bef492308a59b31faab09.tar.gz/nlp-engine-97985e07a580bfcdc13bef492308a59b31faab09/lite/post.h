/*******************************************************************************
Copyright (c) 1998-2010 by Text Analysis International, Inc.
All rights reserved.
********************************************************************************
*
* NAME:	POST.H
* FILE:	lite\post.h
* CR:		11/04/98 AM.
* SUBJ:	Post actions for Pat pass.
* NOTE:	pat.cpp getting too big, so splitting it up.
*
*******************************************************************************/

#ifndef POST_H_
#define POST_H_

#endif
