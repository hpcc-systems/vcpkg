#include <iostream>

int main()
{
    // dummy file to test initialization of qt
    return 0;
}