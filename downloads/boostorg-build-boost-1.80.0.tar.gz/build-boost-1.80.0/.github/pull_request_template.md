  Thank you for your contributions. Main development of B2 has moved to
  https://github.com/bfgroup/b2
