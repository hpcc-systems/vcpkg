---
name: Feature Request
about: Create an issue that requests a feature or other improvement
title: ''
labels: enhancement
assignees: ''

---

  Thank you for your contributions. Main development of B2 has moved to
  https://github.com/bfgroup/b2
