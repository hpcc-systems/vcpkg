
#ifndef __clang__
#  error "This test is for Clang only"
#endif

int main()
{
	return 0;
}