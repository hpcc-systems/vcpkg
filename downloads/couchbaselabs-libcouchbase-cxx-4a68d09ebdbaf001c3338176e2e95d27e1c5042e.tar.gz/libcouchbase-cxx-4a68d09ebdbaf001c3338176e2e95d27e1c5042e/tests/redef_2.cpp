#include <libcouchbase/couchbase++.h>

int main(int, char**) {return 0;}
