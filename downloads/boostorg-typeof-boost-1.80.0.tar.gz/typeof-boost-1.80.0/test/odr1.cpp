// Copyright (C) 2006 Arkadiy Vertleyb
// Use, modification and distribution is subject to the Boost Software
// License, Version 1.0. (http://www.boost.org/LICENSE_1_0.txt)

#include "odr.hpp"
#include <iostream>

int main()
{
    std::cout << "No ODR violation detected" << std::endl; 
    return 0;
}
