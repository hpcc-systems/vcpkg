#!/bin/sh
ragel -o wkt.cpp wkt.rl
