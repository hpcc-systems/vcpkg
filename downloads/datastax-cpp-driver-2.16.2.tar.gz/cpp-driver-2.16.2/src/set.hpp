/*
  Copyright (c) DataStax, Inc.

  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
*/

#ifndef DATASTAX_INTERNAL_SET_HPP
#define DATASTAX_INTERNAL_SET_HPP

#include "allocated.hpp"
#include "allocator.hpp"

#include <set>

namespace datastax { namespace internal {

template <class T, class Compare = std::less<T> >
class Set
    : public Allocated
    , public std::set<T, Compare, internal::Allocator<T> > {
public:
  typedef internal::Allocator<T> Allocator;

  explicit Set(const Compare& compare = Compare(), const Allocator& alloc = Allocator())
      : std::set<T, Compare, Allocator>(compare, alloc) {}

  Set(const Set& other)
      : std::set<T, Compare, Allocator>(other) {}

  template <class InputIt>
  Set(InputIt first, InputIt last, const Compare& compare = Compare(),
      const Allocator& alloc = Allocator())
      : std::set<T, Compare, Allocator>(first, last, compare, alloc) {}
};

}} // namespace datastax::internal

#endif
