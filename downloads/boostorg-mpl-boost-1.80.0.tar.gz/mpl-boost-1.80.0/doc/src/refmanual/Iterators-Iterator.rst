
From the MPL standpoint, all iterators are opaque types. Incrementing, 
dereferencing and the rest of iterator functionality is accessed
through the associated iterator metafunctions.


.. copyright:: Copyright �  2001-2009 Aleksey Gurtovoy and David Abrahams
   Distributed under the Boost Software License, Version 1.0. (See accompanying
   file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
