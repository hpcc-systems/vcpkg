//
//  make_shared_msvc_test.cpp
//
//  Copyright 2017 Peter Dimov
//
//  Distributed under the Boost Software License, Version 1.0.
//  See accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt
//

template<class T> struct value
{
};

#include <boost/make_shared.hpp>

int main()
{
}
