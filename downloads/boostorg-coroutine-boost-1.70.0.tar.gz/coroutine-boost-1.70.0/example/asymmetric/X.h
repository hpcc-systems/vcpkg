#ifndef X_H
#define X_H

struct X
{
    int i;

    X( int i_) :
        i( i_)
    {}
};

#endif // X_H
