# Boost.NumericConversion

The Boost Numeric Conversion library is a collection of tools to describe and perform conversions between values of different [numeric types][1].

The documentation for the library can be found [here][2]

[1]: http://www.boost.org/doc/libs/release/libs/numeric/conversion/doc/html/boost_numericconversion/definitions.html#boost_numericconversion.definitions.numeric_types
[2]: http://www.boost.org/doc/libs/release/libs/numeric/conversion/doc/html/index.html#numeric_conversion.overview
