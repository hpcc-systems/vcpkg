## v1.4.9
* Fixed Issue #22: Error using BT_SetReportFormat (BTRF_TEXT) in x64 build.

## v1.4.8
* CrashExplorer: Fix crash when loading report with MAP file (#21)

## v1.4.7
* PR20: Add custom callback action when handling uncaught exception. 

## v1.4.6
* Include unicode binaries in release package. Close #16.

## v1.4.5
* Release contains BugTrap server apps.

## v1.4.4
PR #8: -sesom42
* Try to get icon from executable. If the message loop of the app is faulty, the icon can not be determined with WM_GETICON.
* typo in solution file for VS8
* show BugTrap window above the active window
* more translation adjustments (German)

## v1.4.3
* PR #7 - Updated the German translation. -sesom42

## v1.4.2
* Initial Release
