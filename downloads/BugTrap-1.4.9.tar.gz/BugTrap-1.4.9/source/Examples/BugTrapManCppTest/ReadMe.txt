Sample Managed C++ GUI application that generates managed exception and catches it with BugTrap.
Open BugTrapManCppTest.sln solution file in Visual Studio and build the application.
Project executables, PDB files and MAP files are located in "BugTrap for Win32 & .NET\Win32\bin" folder.
You may find a description of project code in "BugTrap Developer's Guide".