#pragma once

#pragma unmanaged

void StartUnmanagedThread();

#pragma managed
