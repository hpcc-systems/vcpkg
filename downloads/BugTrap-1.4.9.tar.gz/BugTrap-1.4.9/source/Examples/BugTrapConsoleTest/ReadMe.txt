Sample Win32 console application that generates access violation and uses BugTrap to catch the exception.
Open BugTrapConsoleTest.sln solution file in Visual Studio and build the application.
Project executables and PDB files files are located in "bin\Debug" and "bin\Release" folders.
You may find a description of project code in "BugTrap Developer's Guide".
