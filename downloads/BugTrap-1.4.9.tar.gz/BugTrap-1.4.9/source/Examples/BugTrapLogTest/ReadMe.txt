Sample Win32 application that generates log files using different methods.
Open BugTrapLogTest.sln solution file in Visual Studio and build the application.
Project executables and PDB files files are located in "bin\Debug" and "bin\Release" folders.
You may find a description of project code in "BugTrap Developer's Guide".