//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ImageView.VS.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_POPUP                       202
#define IDD_PROP_FILE                   202
#define IDD_PROP_IMAGE                  203
#define IDR_MAINFRAME256                203
#define IDR_MAINFRAME0                  204
#define IDD_REGISTER                    205
#define IDR_MAINFRAME1                  205
#define IDD_MOVE                        206
#define IDD_PROP_VIEW                   208
#define IDB_BITMAP1                     208
#define IDB_BITMAP2                     209
#define IDD_REGISTER_L                  215
#define IDD_ABOUTBOX_L                  216
#define IDC_IMAGE                       1000
#define IDC_BMP                         1000
#define IDC_JPG                         1001
#define IDC_PNG                         1002
#define IDC_GIF                         1003
#define IDC_MOVE                        1004
#define IDC_TEXT                        1005
#define IDC_SHORTCUT                    1006
#define IDC_FILEICON                    1007
#define IDC_TYPENAME                    1008
#define IDC_FILELOCATION                1009
#define IDC_FILESIZE                    1010
#define IDC_FILEDATE                    1011
#define IDC_FILEATTRIB                  1012
#define IDC_IBMP                        1012
#define IDC_IJPG                        1013
#define IDC_FILENAME                    1013
#define IDC_IPNG                        1014
#define IDC_IGIF                        1015
#define IDC_NUMCOLORS                   1015
#define IDC_BITDEPTH                    1016
#define IDC_IMAGESIZE                   1018
#define IDC_NUMBYTES                    1020
#define IDC_ZOOM                        1021
#define IDC_VIEW                        1022
#define IDC_FILELOCATION_H              1023
#define IDC_MOVE_T                      1024
#define IDC_TYPENAME_H                  1030
#define IDC_FILENAME_H                  1031
#define IDC_FILESIZE_H                  1032
#define IDC_FILEDATE_H                  1033
#define IDC_FILEATTRIB_H                1034
#define IDC_IMAGESIZE_H                 1035
#define IDC_NUMCOLORS_H                 1036
#define IDC_BITDEPTH_H                  1037
#define IDC_NUMBYTES_H                  1038
#define IDC_HEAD                        1039
#define IDC_APPICON                     1040
#define IDC_LICENSE                     1041
#define IDC_REGISTER_H                  1042
#define ID_ZOOM                         32773
#define ID_VIEW_PROPERTIES              32774
#define IDS_CAP_FILE                    32777
#define IDS_CAP_HELP                    32783
#define IDS_CAP_ZOOMTRACK               32785
#define IDS_CAP_VIEW                    32788
#define ID_MENU                         32790
#define IDS_CAP_MENU                    32792
#define ID_VIEW_SCROLLBARS              32802
#define ID_FILE_REGISTER                32807

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        217
#define _APS_NEXT_COMMAND_VALUE         32820
#define _APS_NEXT_CONTROL_VALUE         1043
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
