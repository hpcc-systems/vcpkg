#!/bin/bash
exec llvm-cov gcov "$@"
