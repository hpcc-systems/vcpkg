throw_exception
===============

Common infrastructure for throwing exceptions
