These tests are designed to test Boost.Math's code at really rather high precision
- 500 decimal digits or so.  As such they use their own test data, and take rather 
a long time to run.
